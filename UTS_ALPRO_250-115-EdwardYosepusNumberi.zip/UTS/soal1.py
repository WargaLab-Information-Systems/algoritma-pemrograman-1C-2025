#harga sewa motor

M_metick = 50.000
M_trail = 100.000
M_sport = 75.000 
A = 15.000 * 3
hari = 0
diskon =0.1

harga_sewa = ("print harga sewa mootr * harga motor di sewa")
harga_motor = ("harga motor ** harga hari (total_keseluruhan)")
diskon = ("harga sewa motor ** (total diskon 0.1%))")
jumlah = input("masukan total sewa motor ** total diskon")


