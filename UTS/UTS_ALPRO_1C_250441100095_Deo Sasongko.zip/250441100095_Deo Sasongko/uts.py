rental matic = 50 000
rental trail = 100 000
rental sport = 75 000
diskon distributor = 150 000
asuransi = 15 000


print("tersedia 1 motor trail, matic, sport")
while True
  sewa(int("input motor yang anda sewa)"))
  if sewa == 1
  print ("harga motor 50 000")

  print (" harga motor 100 000")
  diskon = 5% ("jika memasukan kupon")
    
      elif hari >3 = 15 000
         print (tidak ada asuransi haraga sewa 100.000)
  
    else
  
  


