motor_matic = 50000
motor_trail = 100000
motor_sport = 75000
kalimat = "AconkGG"

asuransi = 15000 > 3
diskon = 0.10 > 150000
nama = int(input("masukkan kupon: ", kalimat))


while True: 
    diskon_tambahan = 0.5
    kalimat
    if motor_matic * asuransi:
        diskon
    elif motor_trail * asuransi:
        diskon
    else:
        motor_sport * asuransi
        diskon

print("masukkan nama motor yang ingin di rental (motor matic, motor trail, motor sport):")
print("berapa hari penyewaan:")